"""Data and cycle maths for FlowSync (in-memory, single user)."""
import math
import os
from datetime import date, timedelta

FLOWS = ["Light", "Medium", "Heavy"]
SYMPTOMS = ["Cramps", "Headache", "Bloating", "Fatigue", "Back pain", "Nausea",
            "Breast tenderness", "Acne", "Cravings"]
MOODS = ["Happy", "Calm", "Irritable", "Sad", "Anxious"]
TIMES = ["8:00 AM", "9:00 AM", "10:00 AM", "12:00 PM", "6:00 PM", "8:00 PM"]
ADVANCE_DAYS = 2

PHASE_COLORS = {
    "Menstrual": "#e35b6e",
    "Follicular": "#f2a65a",
    "Ovulatory": "#3fa796",
    "Luteal": "#7b6bd6",
}
PHASE_NOTES = {
    "Menstrual": "Bleeding days at the start of your cycle.",
    "Follicular": "Body prepares to release an egg.",
    "Ovulatory": "Short window around ovulation.",
    "Luteal": "After ovulation until the next period.",
}
PHASE_TIPS = {
    "Menstrual": ("Common in this phase: cramps and tiredness.",
                  "Warmth and rest may help. These are general tips, not medical advice."),
    "Follicular": ("Common in this phase: rising energy and motivation.",
                   "A good time for new routines. These are general tips, not medical advice."),
    "Ovulatory": ("Common in this phase: a little more energy or mild twinges.",
                  "Stay hydrated and keep moving. These are general tips, not medical advice."),
    "Luteal": ("Common in this phase: lower energy, mood changes and cravings.",
               "Rest and gentle movement may help. These are general tips, not medical advice."),
}

# Seed history. A "started" entry carries the flow/symptoms for that period.
STATE = {
    "name": "Yashi Sharma",
    "initials": "YS",
    "cycle_len": 28,
    "settings": {"advance": True, "reminder_time": "9:00 AM", "predicted": True,
                 "followup": True, "ovulation": False, "snoozed_until": None},
    "logs": {
        date(2026, 6, 13): {"period": "started", "flow": "Medium", "symptoms": ["Cramps", "Cravings"], "mood": "Calm"},
        date(2026, 6, 17): {"period": "ended"},
        date(2026, 7, 12): {"period": "started", "flow": "Medium", "symptoms": ["Back pain", "Acne"], "mood": "Calm"},
        date(2026, 7, 16): {"period": "ended"},
        date(2026, 8, 9): {"period": "started", "flow": "Light", "symptoms": ["Fatigue"], "mood": "Calm"},
        date(2026, 8, 12): {"period": "ended"},
        date(2026, 9, 6): {"period": "started", "flow": "Heavy", "symptoms": ["Cramps", "Bloating"], "mood": "Irritable"},
        date(2026, 9, 10): {"period": "ended"},
        date(2026, 10, 5): {"period": "started", "flow": "Medium", "symptoms": ["Cramps", "Headache"], "mood": "Sad"},
        date(2026, 10, 9): {"period": "ended"},
        date(2026, 11, 2): {"period": "started", "flow": "Medium", "symptoms": ["Cramps", "Fatigue"], "mood": "Irritable"},
    },
}


def today():
    pinned = os.environ.get("FLOWSYNC_TODAY")
    return date.fromisoformat(pinned) if pinned else date.today()


def md(d):
    return f"{d:%b} {d.day}"


def wd(d):
    return f"{d:%a}, {d:%b} {d.day}"


def parse_day(text, fallback):
    try:
        return date.fromisoformat(text)
    except (TypeError, ValueError):
        return fallback


def safe_int(value, default):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def periods():
    """Derive periods from the log: each 'started' day opens one, the next 'ended' day closes it."""
    logs = STATE["logs"]
    starts = sorted(d for d, e in logs.items() if e.get("period") == "started")
    out = []
    for i, s in enumerate(starts):
        nxt = starts[i + 1] if i + 1 < len(starts) else None
        ends = [d for d, e in logs.items()
                if e.get("period") == "ended" and s <= d and (nxt is None or d < nxt)]
        end = min(ends) if ends else None
        entry = logs[s]
        out.append({
            "start": s,
            "end": end,
            "length": (end - s).days + 1 if end else None,
            "in_progress": end is None and nxt is None,
            "flow": entry.get("flow"),
            "symptoms": entry.get("symptoms", []),
        })
    return out


def cycle_gaps(ps):
    return [(b["start"] - a["start"]).days for a, b in zip(ps, ps[1:])]


def avg_cycle(ps):
    gaps = cycle_gaps(ps)
    return round(sum(gaps) / len(gaps), 1) if gaps else float(STATE["cycle_len"])


def cycle_len_pred(ps):
    return int(round(avg_cycle(ps)))


def avg_period(ps):
    lens = [p["length"] for p in ps if p["length"]]
    return round(sum(lens) / len(lens), 1) if lens else 5.0


def confidence(ps):
    gaps = cycle_gaps(ps)
    if len(gaps) < 2:
        return "Low"
    return "High" if len(gaps) >= 3 and max(gaps) - min(gaps) <= 2 else "Medium"


def phase_for(day, n):
    ov = n - 14  # ovulation starts on day 14 of a 28-day cycle
    if day <= 5:
        return "Menstrual"
    if day < ov:
        return "Follicular"
    if day <= ov + 2:
        return "Ovulatory"
    return "Luteal"


def cycle_on(d, ps, n):
    past = [p["start"] for p in ps if p["start"] <= d]
    if not past:
        return None
    s = max(past)
    while s + timedelta(days=n) <= d:
        s += timedelta(days=n)
    day = (d - s).days + 1
    return {"start": s, "day": day, "phase": phase_for(day, n),
            "next": s + timedelta(days=n), "n": n}


def phase_ranges(info):
    n, s = info["n"], info["start"]
    ov = n - 14
    spans = [("Menstrual", 1, 5), ("Follicular", 6, ov - 1),
             ("Ovulatory", ov, ov + 2), ("Luteal", ov + 3, n)]
    return [{
        "name": name, "cls": name.lower(), "note": PHASE_NOTES[name],
        "fday": a, "lday": b,
        "start": s + timedelta(days=a - 1), "end": s + timedelta(days=b - 1),
        "days": b - a + 1, "here": name == info["phase"],
    } for name, a, b in spans]


def polar(cx, cy, r, angle):
    rad = math.radians(angle - 90)
    return cx + r * math.cos(rad), cy + r * math.sin(rad)


def arc(cx, cy, r, a0, a1):
    x0, y0 = polar(cx, cy, r, a0)
    x1, y1 = polar(cx, cy, r, a1)
    large = 1 if a1 - a0 > 180 else 0
    return f"M{x0:.2f},{y0:.2f} A{r},{r} 0 {large} 1 {x1:.2f},{y1:.2f}"


def donut(info, ranges, r=104, c=130):
    n = info["n"]
    segs = []
    for rg in ranges:
        a0 = (rg["fday"] - 1) / n * 360 + 0.8
        a1 = rg["lday"] / n * 360 - 0.8
        segs.append({"d": arc(c, c, r, a0, a1), "color": PHASE_COLORS[rg["name"]]})
    mx, my = polar(c, c, r, (info["day"] - 0.5) / n * 360)
    return {"segments": segs, "mx": round(mx, 2), "my": round(my, 2)}


def period_text(p, avg_p):
    s = p["start"]
    end = p["end"] or s + timedelta(days=round(avg_p) - 1)
    if end.month == s.month:
        return f"{md(s)} – {end.day}"
    return f"{md(s)} – {md(end)}"
