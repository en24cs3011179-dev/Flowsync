"""
FlowSync - period flow tracker (Flask). Recreates the six screens:
onboarding, dashboard, calendar, log entry, notifications and history.

    pip install flask
    python app.py          # open http://127.0.0.1:5000

- Data is held in memory and resets on restart (swap STATE for a database).
- Email and password are collected for the UI but not stored.
- FLOWSYNC_TODAY=2026-11-20 pins "today" to the date in the screenshots.
"""
import csv
import io
import os
from calendar import Calendar, monthrange
from datetime import timedelta

from flask import Flask, Response, flash, redirect, render_template, request, url_for

from flowsync_core import (ADVANCE_DAYS, FLOWS, MOODS, PHASE_COLORS, PHASE_TIPS, SYMPTOMS,
                           STATE, TIMES, avg_cycle, avg_period, clamp, confidence,
                           cycle_gaps, cycle_len_pred, cycle_on, donut, md, parse_day,
                           period_text, periods, phase_ranges, safe_int, today, wd)

app = Flask(__name__)
app.secret_key = os.environ.get("FLOWSYNC_SECRET", "dev-only-change-me")

TABS = [("dashboard", "Dashboard"), ("calendar_view", "Calendar"), ("log_entry", "Log entry"),
        ("history", "History"), ("notifications", "Notifications")]


@app.context_processor
def inject_globals():
    return {"tabs": TABS, "initials": STATE["initials"], "wd": wd, "md": md,
            "ADVANCE": ADVANCE_DAYS, "today_iso": today().isoformat()}


# ---------- onboarding ----------
@app.route("/", methods=["GET", "POST"])
def onboarding():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        last = parse_day(request.form.get("last_period"), None)
        if not name or last is None or not request.form.get("agree"):
            flash("Please enter your name, last period date and confirm the disclaimer.")
            return redirect(url_for("onboarding"))
        STATE["name"] = name
        STATE["initials"] = "".join(w[0] for w in name.split()[:2]).upper()
        STATE["cycle_len"] = clamp(safe_int(request.form.get("cycle_len"), 28), 21, 45)
        STATE["logs"] = {last: {"period": "started"}}  # a new profile starts with its first period
        return redirect(url_for("dashboard"))
    return render_template("onboarding.html")


# ---------- dashboard ----------
@app.route("/dashboard")
def dashboard():
    t = today()
    ps = periods()
    info = cycle_on(t, ps, cycle_len_pred(ps))
    ranges = phase_ranges(info)
    current = next(r for r in ranges if r["here"])
    nxt = info["next"]
    days_until = (nxt - t).days
    s = STATE["settings"]
    main, sub = PHASE_TIPS[info["phase"]]
    return render_template(
        "dashboard.html",
        info=info, ranges=ranges, ring=donut(info, ranges),
        days_left=current["lday"] - info["day"],
        countdown=f"In {days_until} day{'s' if days_until != 1 else ''}",
        nxt=nxt, confidence=confidence(ps),
        reminder_day=nxt - timedelta(days=ADVANCE_DAYS),
        reminder_time=s["reminder_time"], on=s["advance"],
        tip_main=main, tip_sub=sub,
        today_text=f"{t:%A}, {t:%B} {t.day}, {t.year}",
    )


@app.post("/reminder/toggle")
def toggle_reminder():
    STATE["settings"]["advance"] = not STATE["settings"]["advance"]
    return redirect(url_for("dashboard"))


# ---------- calendar ----------
@app.route("/calendar")
def calendar_view():
    t = today()
    ps = periods()
    n = cycle_len_pred(ps)
    try:
        y, m = (int(x) for x in request.args.get("month", "").split("-"))
        first = t.replace(year=y, month=m, day=1)
    except ValueError:
        first = t.replace(day=1)
    last = first.replace(day=monthrange(first.year, first.month)[1])
    prev_m = (first - timedelta(days=1)).replace(day=1)
    next_m = (first + timedelta(days=32)).replace(day=1)
    month_key = f"{first:%Y-%m}"

    period_days = set()
    avg_p = avg_period(ps)
    for p in ps:
        end = p["end"] or p["start"] + timedelta(days=round(avg_p) - 1)
        d = p["start"]
        while d <= end:
            period_days.add(d)
            d += timedelta(days=1)

    predicted = set()
    x = ps[-1]["start"] + timedelta(days=n)
    while x <= last:
        if x > t and x >= first:
            predicted.add(x)
        x += timedelta(days=n)

    sel = parse_day(request.args.get("day"), t)
    weeks = []
    for week in Calendar(firstweekday=6).monthdayscalendar(first.year, first.month):
        row = []
        for dd in week:
            if not dd:
                row.append(None)
                continue
            d = first.replace(day=dd)
            info = cycle_on(d, ps, n)
            if d in period_days:
                cls, label = "period", "Period"
            elif d in predicted:
                cls, label = "predicted", "Predicted"
            elif info:
                cls, label = info["phase"].lower(), ("Today" if d == t else "")
            else:
                cls, label = "", ""
            row.append({"day": dd, "iso": d.isoformat(), "cls": cls, "label": label,
                        "today": d == t, "sel": d == sel})
        weeks.append(row)

    sinfo = cycle_on(sel, ps, n)
    if sel in period_days:
        period_status = "Logged"
    elif sel in predicted:
        period_status = "Predicted"
    else:
        period_status = "Not logged today" if sel == t else "Not logged"
    return render_template(
        "calendar.html", first=first, weeks=weeks, prev_key=f"{prev_m:%Y-%m}",
        next_key=f"{next_m:%Y-%m}", month_key=month_key, sel=sel, sinfo=sinfo,
        period_status=period_status,
        next_period=sinfo["next"] if sinfo else None,
        reminder_day=sinfo["next"] - timedelta(days=ADVANCE_DAYS) if sinfo else None,
    )


# ---------- log entry ----------
@app.route("/log", methods=["GET", "POST"])
def log_entry():
    t = today()
    if request.method == "POST":
        d = parse_day(request.form.get("date"), t)
        period = request.form.get("period")
        flow = request.form.get("flow")
        mood = request.form.get("mood")
        entry = {
            "flow": flow if flow in FLOWS else None,
            "symptoms": [s for s in request.form.getlist("symptoms") if s in SYMPTOMS],
            "mood": mood if mood in MOODS else None,
        }
        if period in ("started", "ended"):
            entry["period"] = period
        has_data = "period" in entry or entry["flow"] or entry["symptoms"] or entry["mood"]
        if has_data:
            STATE["logs"][d] = entry
        else:
            STATE["logs"].pop(d, None)
        flash(f"Entry saved for {wd(d)}.")
        return redirect(url_for("log_entry", day=d.isoformat()))

    d = parse_day(request.args.get("day"), t)
    ps = periods()
    return render_template(
        "log.html", d=d, entry=STATE["logs"].get(d, {}), flows=FLOWS,
        symptoms=SYMPTOMS, moods=MOODS, cur=len(ps), avg=avg_cycle(ps), conf=confidence(ps),
    )


# ---------- notifications ----------
@app.route("/notifications", methods=["GET", "POST"])
def notifications():
    s = STATE["settings"]
    if request.method == "POST":
        for key in ("advance", "predicted", "followup", "ovulation"):
            s[key] = request.form.get(key) == "on"
        s["reminder_time"] = request.form.get("reminder_time", s["reminder_time"])
        flash("Notification settings saved.")
        return redirect(url_for("notifications"))

    t = today()
    info = cycle_on(t, periods(), cycle_len_pred(periods()))
    nxt = info["next"]
    upcoming = []
    if s["advance"]:
        upcoming.append({"when": nxt - timedelta(days=ADVANCE_DAYS),
                         "label": f"{ADVANCE_DAYS}-day advance reminder", "color": PHASE_COLORS["Menstrual"]})
    if s["predicted"]:
        upcoming.append({"when": nxt, "label": "Predicted start date", "color": PHASE_COLORS["Follicular"]})
    if s["followup"]:
        upcoming.append({"when": nxt + timedelta(days=3), "label": "Follow-up if not logged",
                         "color": PHASE_COLORS["Luteal"]})
    if s["ovulation"]:
        upcoming.append({"when": nxt + timedelta(days=13), "label": "Ovulation window begins",
                         "color": PHASE_COLORS["Ovulatory"]})
    upcoming.sort(key=lambda u: u["when"])
    return render_template("notifications.html", s=s, times=TIMES, nxt=nxt,
                           upcoming=upcoming, advance=ADVANCE_DAYS)


@app.post("/notifications/snooze")
def snooze():
    until = today() + timedelta(days=1)
    STATE["settings"]["snoozed_until"] = until.isoformat()
    flash(f"Reminders snoozed until {wd(until)}.")
    return redirect(url_for("notifications"))


# ---------- history ----------
@app.route("/history")
def history():
    ps = periods()
    span = request.args.get("span", "6")
    symptom = request.args.get("symptom", "All")
    cutoff = ps[-int(span):] if span.isdigit() else ps
    gaps = {p["start"]: g for p, g in zip(ps, cycle_gaps(ps) + [None])}
    avg_p = avg_period(ps)
    rows = []
    for p in reversed(cutoff):
        if symptom != "All" and symptom not in p["symptoms"]:
            continue
        g = gaps[p["start"]]
        rows.append({
            "start": p["start"], "period": period_text(p, avg_p), "in_progress": p["in_progress"],
            "cycle": f"{g} days" if g else "—", "flow": p["flow"],
            "flow_cls": f"flow-{p['flow'].lower()}" if p["flow"] else "",
            "symptoms": ", ".join(p["symptoms"]) or "—",
        })
    bars = [{"label": f"{p['start']:%b}", "value": g, "px": round(g / 35 * 150)}
            for p, g in zip(ps, cycle_gaps(ps))][-5:]
    return render_template(
        "history.html", rows=rows, span=span, symptom=symptom, symptoms=SYMPTOMS,
        avg_cycle=avg_cycle(ps), avg_period=avg_p, cycles=len(ps), bars=bars,
    )


@app.route("/history/export")
def export_history():
    ps = periods()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["cycle_start", "period_end", "period_length_days", "cycle_length_days",
                     "flow", "symptoms"])
    gaps = cycle_gaps(ps) + [None]
    for p, g in zip(ps, gaps):
        writer.writerow([p["start"].isoformat(), p["end"].isoformat() if p["end"] else "",
                         p["length"] or "", g or "", p["flow"] or "", "; ".join(p["symptoms"])])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=flowsync-history.csv"})


@app.post("/history/delete")
def delete_entry():
    d = parse_day(request.form.get("day"), None)
    if d:
        STATE["logs"].pop(d, None)
        flash("Entry deleted.")
    return redirect(url_for("history"))


if __name__ == "__main__":
    app.run(debug=True)
